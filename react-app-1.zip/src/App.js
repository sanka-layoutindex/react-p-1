
import './App.css';
import './styles/main.scss'
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './components/pages/Home';


function App() {
  return (
      <>
      <Home/>
      </>
  );
}

export default App;
